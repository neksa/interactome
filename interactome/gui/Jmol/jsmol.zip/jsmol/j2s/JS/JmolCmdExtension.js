Clazz.declarePackage ("JS");
Clazz.declareInterface (JS, "JmolCmdExtension");
